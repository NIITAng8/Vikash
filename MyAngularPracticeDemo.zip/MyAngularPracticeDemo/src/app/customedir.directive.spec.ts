import { CustomedirDirective } from './customedir.directive';

describe('CustomedirDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomedirDirective();
    expect(directive).toBeTruthy();
  });
});
