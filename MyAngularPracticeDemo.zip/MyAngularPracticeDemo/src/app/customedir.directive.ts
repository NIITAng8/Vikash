import { Directive } from '@angular/core';

@Directive({
  selector: '[appCustomedir]'
})
export class CustomedirDirective {

  constructor() { }

}
