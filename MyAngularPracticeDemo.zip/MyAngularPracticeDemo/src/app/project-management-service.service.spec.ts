import { TestBed } from '@angular/core/testing';

import { ProjectManagementServiceService } from './project-management-service.service';

describe('ProjectManagementServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProjectManagementServiceService = TestBed.get(ProjectManagementServiceService);
    expect(service).toBeTruthy();
  });
});
