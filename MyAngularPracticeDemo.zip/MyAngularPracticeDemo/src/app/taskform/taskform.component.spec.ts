import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskformComponent } from './taskform.component';

describe('TaskformComponent', () => {
  let component: TaskformComponent;
  let fixture: ComponentFixture<TaskformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskformComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
