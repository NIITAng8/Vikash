import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataShowCardComponent } from './data-show-card.component';

describe('DataShowCardComponent', () => {
  let component: DataShowCardComponent;
  let fixture: ComponentFixture<DataShowCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataShowCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataShowCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
