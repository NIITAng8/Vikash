import { employeemodel } from './data-show-card.modal.component';
import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import {EmployeeAddPopupComponent} from '../employee-add-popup/employee-add-popup.component';



@Component({
  selector: 'app-data-show-card',
  templateUrl: './data-show-card.component.html',
  styleUrls: ['./data-show-card.component.css']
})
export class DataShowCardComponent implements OnInit {
employees:employeemodel[];
  constructor(public dialog:MatDialog) { 
    this.employees=[new employeemodel("Vikash","E34147","Developer",true),
    new employeemodel("Shubhanshu","E4146","Developer",false),
    new employeemodel("Bharat","E4145","Developer",false)]

  }
  openDialog(){
    const dialogRef=this.dialog.open(EmployeeAddPopupComponent,{
      width:'250px'
    }) 
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        let dialogname = new employeemodel(result.name, result.eid,
          result.role, false)
        this.employees.unshift(dialogname);
        console.log(result);
      }
    })
  }
  ngOnInit() {
  }

}
