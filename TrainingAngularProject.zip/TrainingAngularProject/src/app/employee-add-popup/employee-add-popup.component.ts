import { DataShowCardComponent } from './../data-show-card/data-show-card.component';
import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';


@Component({
  selector: 'app-employee-add-popup',
  templateUrl: './employee-add-popup.component.html',
  styleUrls: ['./employee-add-popup.component.css']
})
export class EmployeeAddPopupComponent implements OnInit {
  roles=["Developer","Manager"];
  selectedoption:string="Developer"
  constructor(public dialogRef: MatDialogRef<DataShowCardComponent>) { }
  CloseDialog() {
    this.dialogRef.close();
  }
  addmember(name,eid){
    this.dialogRef.close({neha:name,eid:eid,role:this.selectedoption});
 
  }


  ngOnInit() {
  }

}
