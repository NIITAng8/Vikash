import { formmodel } from './formModel.model';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ProjectmanagementService } from '../projectmanagement.service';
import { Router } from '../../../node_modules/@angular/router';
import {
  MAT_MOMENT_DATE_FORMATS,
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

@Component({
  selector: 'app-projectform',
  templateUrl: './projectform.component.html',
  styleUrls: ['./projectform.component.css'],
  providers:[{provide: MAT_DATE_LOCALE, useValue: 'ja-JP'},{
    provide: DateAdapter,
    useClass: MomentDateAdapter,
    deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
  },
  {provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS}],
})
export class ProjectformComponent implements OnInit {
  projectForm: FormGroup;
  constructor(private fb: FormBuilder
    , private pmservice: ProjectmanagementService,private route:Router,private _adapter: DateAdapter<any>) {
      this._adapter.setLocale('fr');
    this.createform()
  }

  
  createform() {
    this.projectForm = this.fb.group({
      projectname: ['',[Validators.required,Validators.minLength(5)]],
      startdate: ['',Validators.required],
      enddate: ['',Validators.required],
      efforthours: [],
      effortcost: ['',Validators.pattern('[0-9]*')]
    })
  }
  onSubmit(){
    console.log(this.projectForm.value);
    let formdata: formmodel = this.projectForm.value;
    this.pmservice.saveProjectinfo(formdata).then(result =>
      {
        console.log(result)
        this.route.navigate(['']);
      }
      ,
      res => console.log(res))
      .catch(err => console.log(err));
  }
 
  ngOnInit() {
  }

}
